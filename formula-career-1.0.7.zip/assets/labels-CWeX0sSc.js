function r(e){return e<20?"rookie":e<50?"developing":e<80?"experienced":"veteran"}function n(e){return e<50?"low":e<70?"medium":e<85?"high":"veryHigh"}export{r as e,n as p};
