import{g as a}from"./techTree-qHXf3ry_.js";function u(e,r){return a(r)?e(`rnd.upgrades.${r}.name`):r}function p(e,r){return a(r)?e(`rnd.upgrades.${r}.desc`):""}export{p as a,u};
