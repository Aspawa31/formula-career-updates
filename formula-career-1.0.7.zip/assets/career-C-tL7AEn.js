const a=["coach","manager","simulator","pr"];export{a as I};
